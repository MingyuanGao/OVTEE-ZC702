# Top level script to generate the otzone.elf

TOP=`pwd`
SMP_BUILD="y"

# Kernel
KERNEL_DIR=$TOP/kernel/first/linux-xlnx
BOOTWRAPPER=$TOP/bootwrapper/first

# Its assumed the kernel is configured.
echo "Building first kernel..."
if [ $SMP_BUILD = y ]
then
    echo "SMP Enabled kernel "
	make ARCH=arm -C $KERNEL_DIR xilinx_zynq_base_trd_defconfig
else
    echo "SMP is not enabled"
	make ARCH=arm -C $KERNEL_DIR xilinx_zynq_base_trd_nosmp_defconfig
fi

make -j5 ARCH=arm -C $KERNEL_DIR

#Bootwrapper
#Its assumed the filesystem and dtbs are generated
echo "Bootwrapping first kernel"
make -C $BOOTWRAPPER clean; 
make -C $BOOTWRAPPER
