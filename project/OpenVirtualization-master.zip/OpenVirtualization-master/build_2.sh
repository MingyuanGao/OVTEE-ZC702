#Copying the binaries to the root file system

TOP=`pwd`
BOOTWRAPPER=$TOP/bootwrapper/first
TRUSTZONE_DIR=$TOP/../..

sh cp_bin1.sh $TRUSTZONE_DIR

#Bootwrapper
#Its assumed the filesystem and dtbs are generated
echo "Bootwrapping first kernel with the updated filesystem"
make -C $BOOTWRAPPER clean;
make -C $BOOTWRAPPER

