#/bin/sh

TOP=`pwd`
TMP_MNT1=/tmp/kernel1

TRUSTZONE_DIR=$1

echo "Copying filesystem for first kernel";
mkdir -p $TMP_MNT1 
cp filesystem/first/ramdisk8M.image.gz $TMP_MNT1/ramdisk8M.image.gz
cd $TMP_MNT1
gunzip ramdisk8M.image.gz
sleep 1;
mkdir -p mnt
mount ramdisk8M.image mnt/

cp -f $TRUSTZONE_DIR/tzone_sdk/bin/otz_client.ko 			$TMP_MNT1/mnt/root/otz/
cp -f $TRUSTZONE_DIR/tzone_sdk/bin/otzapp.elf 				$TMP_MNT1/mnt/root/otz/
cp -f $TRUSTZONE_DIR/tzone_sdk/bin/otz_tee_app.elf 		$TMP_MNT1/mnt/root/otz/
cp -f $TRUSTZONE_DIR/tzone_sdk/otz_api/build/libotzapi.so 	$TMP_MNT1/mnt/lib/

cp -f $TOP/patches/rcS $TMP_MNT1/mnt/etc/init.d/rcS

umount mnt/
gzip ramdisk8M.image
sleep 1
cd $TOP 
cp -f $TMP_MNT1/ramdisk8M.image.gz $TOP/filesystem/first/ramdisk8M.image.gz
