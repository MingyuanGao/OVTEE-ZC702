#Top level script to generate the otzone.elf

TOP=`pwd`
SMP_BUILD="n"

# Kernel
KERNEL_DIR_1=$TOP/kernel/first/linux-xlnx
BOOTWRAPPER_1=$TOP/bootwrapper/first
TRUSTZONE_DIR=$TOP/trustzone

# Set environment for kernel 3.8.0
source $TOP/kernel380env.sh

# Its assumed the kernel is configured.
echo "Building first kernel..."
if [ $SMP_BUILD = y ]
then
    echo "SMP Enabled kernel "
		make ARCH=arm -C $KERNEL_DIR_1 xilinx_zynq_base_trd_defconfig
else
    echo "SMP is not enabled"
        make ARCH=arm -C $KERNEL_DIR_1 xilinx_zynq_base_trd_nosmp_defconfig
fi

make -j5 ARCH=arm -C $KERNEL_DIR_1 

# Set environment for Open Virtualization
source $TOP/ovenv.sh

#Bootwrapper
#Its assumed the filesystem and dtbs are generated
echo "Bootwrapping first kernel"
make -C $BOOTWRAPPER_1 clean; 
make -C $BOOTWRAPPER_1


#sierrTEE 
echo "Building sierraTEE..."
cd $TRUSTZONE_DIR/tzone_sdk
make clean; make;

#Copying the binaries to the root file system
echo "Copying Binaries..."
cd $TOP
sudo sh cp_bin1.sh $TRUSTZONE_DIR

#Bootwrapper
#Its assumed the filesystem and dtbs are generated
echo "Bootwrapping first kernel with the updated filesystem"
make -C $BOOTWRAPPER_1 clean; 
make -C $BOOTWRAPPER_1

echo "Building sierraTEE for the second time with updated kernel..."
cd $TRUSTZONE_DIR/tzone_sdk
make clean; make;

mv $TRUSTZONE_DIR/tzone_sdk/bin/SierraTEE.bin $TOP/bin/
