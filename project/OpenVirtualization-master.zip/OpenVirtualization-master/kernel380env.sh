export CROSS_COMPILE=/opt/CodeSourcery/arm-2011-03-42/bin/arm-none-eabi-
export CROSS_COMPILE_NEWLIB=/opt/arm-sw-newlib/bin/arm-none-eabi-
export PATH=$PATH:/opt/CodeSourcery/arm-2010q1/bin/:/opt/CodeSourcery/arm-2011-03-42/bin/


